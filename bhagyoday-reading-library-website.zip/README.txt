# Bhagyoday Reading Library Website

This is a standalone static website. It does not depend on Emergent.

## Before publishing
Open `script.js` and replace:
- `phone`
- `whatsapp`
- `maps`

The design is responsive and works on mobile and desktop.

## Free publishing
You can publish this as a static site with GitHub Pages. GitHub Pages supports custom domains, including an apex domain such as `bhagyodayreading.com`.

Cloudflare Pages is another option for static hosting and supports custom domains.

## Important
If you want online admission/payment, a backend and payment provider must be added separately.
