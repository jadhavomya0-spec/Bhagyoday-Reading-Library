// EDIT ONLY THESE 3 VALUES when you have the real details.
const CONFIG = {
  phone: "+91XXXXXXXXXX",
  whatsapp: "91XXXXXXXXXX",
  maps: "https://maps.google.com/?q=Bhagyoday+Reading+Library"
};

const wa = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent("Hello, मला Bhagyoday Reading Library बद्दल माहिती हवी आहे.")}`;
document.querySelectorAll("#whatsappTop,#whatsappBtn,#whatsappBottom").forEach(x=>x.href=wa);
document.querySelectorAll("#callBtn,#callBottom").forEach(x=>x.href=`tel:${CONFIG.phone}`);
document.querySelector("#directions").href=CONFIG.maps;
document.querySelector("#year").textContent=new Date().getFullYear();

function toggleMenu(){document.querySelector("#nav").classList.toggle("open")}
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=>document.querySelector("#nav").classList.remove("open")));
